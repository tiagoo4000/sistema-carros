<?php

namespace App\Actions;

use App\Models\Lance;
use App\Models\Lote;
use App\Models\Usuario;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cache;
use Exception;

class RegistrarLanceAction
{
    public function execute(Usuario $usuario, Lote $lote, float $valor)
    {
        $leilao = $lote->leilao()->firstOrFail();
        
        // 1. Validar janelas de tempo (não depende de status manual)
        $now = now();
        $start = $leilao->data_inicio;
        $end = $lote->ends_at ?: $leilao->data_fim;
        if ($start && $now->lt($start)) {
            throw new Exception('Este lote ainda não está aberto para lances.');
        }
        if ($end && $now->gte($end)) {
            throw new Exception('Este lote foi encerrado.');
        }
        // 2. Bloquear se já vendido/encerrado logicamente
        if (in_array($lote->status, ['vendido', 'sem_lances', 'reservado', 'arrematado'])) {
            throw new Exception('Este lote não aceita mais lances.');
        }

        // 4. Lock atômico via Redis para evitar Race Conditions
        $lock = Cache::lock('lote_lance_' . $lote->id, 5); // 5 segundos de lock

        try {
            return $lock->block(3, function () use ($usuario, $lote, $leilao, $valor) {
                // Refresh no model para garantir dados atualizados
                $lote->refresh();
                $leilao->refresh();
                
                // Revalidar janela de tempo dentro do lock
                $now = now();
                $start = $leilao->data_inicio;
                $end = $lote->ends_at ?: $leilao->data_fim;
                if (($start && $now->lt($start)) || ($end && $now->gte($end))) {
                    throw new Exception('A janela de lances para este lote não está ativa.');
                }
                
                $maiorLance = $lote->maiorLance;
                $valorAtual = $maiorLance ? $maiorLance->valor : $lote->valor_inicial;
                
                // 5. Validar valor do lance
                if ($valor <= $valorAtual) {
                    throw new Exception("O lance deve ser maior que o valor atual: R$ " . number_format($valorAtual, 2, ',', '.'));
                }
                
                $incrementoMinimo = $lote->valor_minimo_incremento;
                if ($maiorLance && ($valor < $valorAtual + $incrementoMinimo)) {
                    throw new Exception("O lance deve superar o atual em pelo menos R$ " . number_format($incrementoMinimo, 2, ',', '.'));
                }

                $prevUsuarioId = $maiorLance?->usuario_id;
                return DB::transaction(function () use ($usuario, $lote, $leilao, $valor, $prevUsuarioId) {
                    $lance = Lance::create([
                        'lote_id' => $lote->id,
                        'usuario_id' => $usuario->id,
                        'valor' => $valor,
                    ]);

                    // Reset status if it was in warning state
                    if (in_array($lote->status, ['dou_lhe_1', 'dou_lhe_2'])) {
                        $lote->status = 'aberto';
                        $lote->save();
                        broadcast(new \App\Events\LoteStatusUpdated($lote));
                    } else {
                        // Even if status didn't change, we should broadcast the new bid via the status update event 
                        // so the card updates the price and potential visual cues
                        broadcast(new \App\Events\LoteStatusUpdated($lote));
                    }

                    // Removido: extensão automática global do leilão (anti-sniper).
                    // Regra: não recalcular/estender end_time sem regra explícita configurada por lote.

                    // Removido: notificação push para usuário ultrapassado

                    return $lance;
                });
            });
        } catch (\Illuminate\Contracts\Cache\LockTimeoutException $e) {
            throw new Exception('Não foi possível processar seu lance devido à alta demanda. Tente novamente.');
        }
    }
}
